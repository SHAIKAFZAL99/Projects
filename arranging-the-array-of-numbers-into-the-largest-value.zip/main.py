from functools import cmp_to_key
def largest_number(numbers):
    def comapare(x,y):
        xy = x + y
        yx = y + x
        if xy > yx:
            return -1
        elif xy<yx:
            return 1
        else:
            return 0
    sorted_numbers = sorted(map(str,numbers), key=cmp_to_key(comapare))
    return int("".join(sorted_numbers))

#Test case
numbers=[54,546,548,60]
result = largest_number(numbers)
print("Largest Number :",result)