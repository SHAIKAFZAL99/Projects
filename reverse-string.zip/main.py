str1="codecode"
print(str1)
print()
print(str1[::-1])