l1=[54,546,548,60]
max_value = l1[0]
min_value = l1[0]
for x in l1[1:]:
    if x> max_value:
        max_value = x
    elif x<min_value:
        min_value = x
print("",max_value, min_value)