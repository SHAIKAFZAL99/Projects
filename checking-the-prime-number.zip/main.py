def is_prime(number):
 for x in range(2,number):
    if number%x==0:
        return False
    return True
#Test cases

number1=3
number2=4

if is_prime(number1):
    print("Yes")
else:
    print("No")
    
if is_prime(number2):
    print("Yes")
else:
    print("No")