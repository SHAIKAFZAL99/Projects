number=988
print(type(number))
str1=str(number)
l1=[]
for x in str1[::-1]:
    l1.append(x)
output1="".join(l1)
result=int(output1)
print()
print("reverse of the Number : ",result)
print(type(result))